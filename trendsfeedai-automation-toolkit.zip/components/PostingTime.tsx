import React, { useState, useContext } from 'react';
import ToolCard from './ToolCard';
import { generateContent } from '../services/geminiService';
import OutputDisplay from './OutputDisplay';
import { UserProfileContext } from '../context/UserProfileContext';

const PostingTime: React.FC = () => {
  const { userProfile } = useContext(UserProfileContext);
  const [platform, setPlatform] = useState('tiktok');
  const [day, setDay] = useState('monday');
  const [times, setTimes] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState('');

  const getPostingTimes = async () => {
    setIsLoading(true);
    setError('');
    setTimes('');

    const systemInstruction = `You are a social media expert providing concise posting time advice.`;
    const prompt = `Based on the latest data, what are the best times to post on ${platform} on a ${day} for maximum engagement, specifically for the content niche: "${userProfile.niche || 'general topics'}". Provide 2-3 'best' times and 2-3 'good' times. Keep the answer concise and formatted clearly. Mention the timezone if available.`;
    
    try {
      const result = await generateContent(prompt, systemInstruction);
      setTimes(result);
    } catch (err) {
      setError('Failed to fetch posting times. Please try again.');
      console.error(err);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <ToolCard title="Best Posting Time" icon="⏰">
      <div className="form-group">
        <label htmlFor="platform" className="block text-sm font-medium text-gray-700 mb-1">Platform:</label>
        <select
          id="platform"
          value={platform}
          onChange={(e) => setPlatform(e.target.value)}
          className="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 bg-white"
        >
          <option value="tiktok">TikTok</option>
          <option value="instagram">Instagram Reels</option>
          <option value="youtube">YouTube Shorts</option>
        </select>
      </div>
      <div className="form-group">
        <label htmlFor="dayOfWeek" className="block text-sm font-medium text-gray-700 mb-1">Day of Week:</label>
        <select
          id="dayOfWeek"
          value={day}
          onChange={(e) => setDay(e.target.value)}
          className="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 bg-white"
        >
          <option value="monday">Monday</option>
          <option value="tuesday">Tuesday</option>
          <option value="wednesday">Wednesday</option>
          <option value="thursday">Thursday</option>
          <option value="friday">Friday</option>
          <option value="saturday">Saturday</option>
          <option value="sunday">Sunday</option>
        </select>
      </div>
      <button
        onClick={getPostingTimes}
        disabled={isLoading}
        className="w-full bg-gradient-to-r from-indigo-500 to-purple-600 text-white font-bold py-2 px-4 rounded-md hover:opacity-90 transition-opacity disabled:opacity-50"
      >
        {isLoading ? 'Searching...' : 'Find Best Times ✨'}
      </button>
      {error && <p className="text-red-500 text-sm mt-2">{error}</p>}
      <OutputDisplay text={times} isLoading={isLoading} />
    </ToolCard>
  );
};

export default PostingTime;