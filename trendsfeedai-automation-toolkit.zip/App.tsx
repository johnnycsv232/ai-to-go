import React, { useState } from 'react';
import PostingTime from './components/PostingTime';
import EngagementCalculator from './components/EngagementCalculator';
import RevenueEstimator from './components/RevenueEstimator';
import ImageGenerator from './components/ImageGenerator';
import ProfileManager from './components/ProfileManager';
import AnalyticsDashboard from './components/AnalyticsDashboard';
import UnifiedAssistant from './components/UnifiedAssistant';


const App: React.FC = () => {
  const [showAnalytics, setShowAnalytics] = useState(false);

  return (
    <div className="min-h-screen bg-gray-900 text-white font-sans p-4 sm:p-6 lg:p-8">
      <div className="container mx-auto max-w-7xl">
        <header className="text-center mb-8 relative">
          <h1 className="text-4xl md:text-5xl font-bold mb-2 text-shadow text-white">
            🚀 TrendsFeed<span className="text-[#00E5FF]">AI</span> Gemini Unified Assistant
          </h1>
          <p className="text-lg md:text-xl text-gray-300">
            Your end-to-end solution for creating viral short-form video content.
          </p>
          <button
            onClick={() => setShowAnalytics(!showAnalytics)}
            className="absolute top-0 right-0 mt-2 mr-2 bg-white/10 text-white font-bold py-2 px-4 rounded-lg hover:bg-white/20 transition-colors text-sm"
          >
            {showAnalytics ? 'Hide Analytics' : 'View Analytics'}
          </button>
        </header>

        <main className="space-y-8">
          {showAnalytics && <AnalyticsDashboard />}

          {/* Section 1: Core Profile */}
          <ProfileManager />
          
          {/* Section 2: The Unified Assistant */}
          <UnifiedAssistant />
          
          {/* Section 3: Analysis & Growth Tools */}
          <div>
            <h2 className="text-2xl font-bold text-white text-shadow mb-4 text-center border-t border-white/10 pt-8">Analysis & Growth Tools</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-6">
              <EngagementCalculator />
              <RevenueEstimator />
              <PostingTime />
            </div>
          </div>

           {/* Section 4: Creative Utilities */}
           <div>
            <h2 className="text-2xl font-bold text-white text-shadow mb-4 text-center border-t border-white/10 pt-8">Creative Utilities</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-6">
              <ImageGenerator />
            </div>
          </div>
        </main>
      </div>
    </div>
  );
};

export default App;