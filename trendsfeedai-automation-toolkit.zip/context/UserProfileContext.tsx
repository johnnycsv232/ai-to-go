
import React, { createContext, useState, useEffect, ReactNode } from 'react';
import type { UserProfile } from '../types';

const defaultProfile: UserProfile = {
  niche: 'general trending news',
  audience: 'Gen Z and young millennials',
  style: 'fast-paced, informative, and engaging',
};

interface UserProfileContextType {
  userProfile: UserProfile;
  setUserProfile: React.Dispatch<React.SetStateAction<UserProfile>>;
  saveProfile: (profile: UserProfile) => void;
}

export const UserProfileContext = createContext<UserProfileContextType>({
  userProfile: defaultProfile,
  setUserProfile: () => {},
  saveProfile: () => {},
});

export const UserProfileProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [userProfile, setUserProfile] = useState<UserProfile>(defaultProfile);
  const [isLoaded, setIsLoaded] = useState(false);

  useEffect(() => {
    try {
      const storedProfile = localStorage.getItem('userProfile');
      if (storedProfile) {
        setUserProfile(JSON.parse(storedProfile));
      }
    } catch (error) {
      console.error("Failed to parse user profile from localStorage", error);
    }
    setIsLoaded(true);
  }, []);

  const saveProfile = (profile: UserProfile) => {
    try {
      localStorage.setItem('userProfile', JSON.stringify(profile));
      setUserProfile(profile);
    } catch (error) {
      console.error("Failed to save user profile to localStorage", error);
    }
  };

  const value = {
    userProfile,
    setUserProfile,
    saveProfile
  };

  // Render children only after profile has been loaded from localStorage
  return (
    <UserProfileContext.Provider value={value}>
      {isLoaded ? children : null}
    </UserProfileContext.Provider>
  );
};
