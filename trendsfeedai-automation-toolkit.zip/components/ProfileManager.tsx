
import React, { useState, useContext, useEffect } from 'react';
import ToolCard from './ToolCard';
import { UserProfileContext } from '../context/UserProfileContext';

const ProfileManager: React.FC = () => {
  const { userProfile, saveProfile } = useContext(UserProfileContext);
  const [niche, setNiche] = useState(userProfile.niche);
  const [audience, setAudience] = useState(userProfile.audience);
  const [style, setStyle] = useState(userProfile.style);
  const [saveStatus, setSaveStatus] = useState('');

  useEffect(() => {
    setNiche(userProfile.niche);
    setAudience(userProfile.audience);
    setStyle(userProfile.style);
  }, [userProfile]);

  const handleSave = () => {
    saveProfile({ niche, audience, style });
    setSaveStatus('Profile Saved! ✅');
    setTimeout(() => setSaveStatus(''), 2000);
  };

  return (
    <ToolCard title="Creator Profile" icon="👤">
      <p className="text-sm text-gray-600 mb-4">
        Define your brand voice here. The AI will use this profile to tailor all content specifically for you.
      </p>
      <div className="space-y-4">
        <div>
          <label htmlFor="niche" className="block text-sm font-medium text-gray-700 mb-1">Your Niche:</label>
          <input
            type="text"
            id="niche"
            value={niche}
            onChange={(e) => setNiche(e.target.value)}
            placeholder="e.g., AI and future technology"
            className="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-indigo-500 focus:border-indigo-500"
          />
        </div>
        <div>
          <label htmlFor="audience" className="block text-sm font-medium text-gray-700 mb-1">Target Audience:</label>
          <input
            type="text"
            id="audience"
            value={audience}
            onChange={(e) => setAudience(e.target.value)}
            placeholder="e.g., Tech enthusiasts and professionals aged 25-40"
            className="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-indigo-500 focus:border-indigo-500"
          />
        </div>
        <div>
          <label htmlFor="style" className="block text-sm font-medium text-gray-700 mb-1">Content Style:</label>
          <input
            type="text"
            id="style"
            value={style}
            onChange={(e) => setStyle(e.target.value)}
            placeholder="e.g., Witty, informative, and slightly sarcastic"
            className="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-indigo-500 focus:border-indigo-500"
          />
        </div>
        <div className="flex items-center justify-between">
            <button
                onClick={handleSave}
                className="w-full bg-gradient-to-r from-indigo-500 to-purple-600 text-white font-bold py-2 px-4 rounded-md hover:opacity-90 transition-opacity"
            >
                Save Profile
            </button>
            {saveStatus && <span className="text-green-600 ml-4 text-sm font-medium">{saveStatus}</span>}
        </div>
      </div>
    </ToolCard>
  );
};

export default ProfileManager;
