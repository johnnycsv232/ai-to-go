import type React from 'react';

export interface ToolCardProps {
  title: string;
  icon: React.ReactNode;
  children: React.ReactNode;
}

export interface StatBoxProps {
    label: string;
    value: string | number;
}

export interface UserProfile {
  niche: string;
  audience: string;
  style: string;
}

export interface VideoFrame {
  data: string; // base64
  timestamp: number; // seconds
}

export interface HookScore {
  urgency: number;
  curiosity: number;
  emotion: number;
  clarity: number;
}

export interface AnalyticsEntry {
  id: string;
  timestamp: number;
  tool: 'Unified Analysis' | 'Image Generation' | 'Other';
  details: {
    inputType?: 'Video' | 'Topic';
    videoFileName?: string;
  }
}

// === UNIFIED ASSISTANT V2.0 TYPES (Strict Schema) ===

export interface Analysis {
    hook_strength: number;
    pacing_score: number;
    viral_potential: number;
    emotional_peaks: { timestamp: number; emotion: string; intensity: number }[];
    retention_curve: number[];
    accessibility_score: number;
}

export interface ExtractedFrame {
    timestamp: number;
    purpose: "thumbnail" | "hook" | "climax" | "cta";
    visual_elements: string[];
    emotion_detected: string;
    text_readability: number;
    frameData?: string; // Client-side added
}

export interface Thumbnail {
    primary_text: string;
    secondary_text: string;
    visual_style: "minimal" | "bold" | "collage" | "cinematic";
    color_scheme: { primary: string; secondary: string; accent: string };
    element_layout: { type: string; position: string; size: string }[];
    a_b_variant: string;
}

export interface CaptionsTikTok {
    primary: string;
    hook_variant_a: string;
    hook_variant_b: string;
    engagement_triggers: string[];
}

export interface CaptionsInstagram {
    primary: string;
    first_line: string;
    cta_options: string[];
    save_triggers: string[];
}

export interface CaptionsYouTube {
    title: string;
    description_snippet: string;
    chapters: { time: string; title: string }[];
    seo_keywords: string[];
}

export interface HashtagsTikTok {
    primary: string[];
    experimental: string[];
    branded: string[];
}

export interface HashtagsInstagram {
    visible: string[];
    hidden: string[];
    location_tags: string[];
}

export interface HashtagsYouTube {
    tags: string[];
    category: string;
}

export interface Audio {
    voiceover_script: string;
    duration: number;
    tts_config: {
        platform_variants: {
            tiktok: { voice_id: string; params: object };
            instagram: { voice_id: string; params: object };
            youtube: { voice_id: string; params: object };
        };
    };
    music_recommendation: {
        genre: string;
        bpm: number;
        energy_level: string;
        trending_audio_id: string;
    };
    sound_effects: { type: string; timestamp: number }[];
}

export interface ContentPackage {
    thumbnail: Thumbnail;
    captions: {
        tiktok: CaptionsTikTok;
        instagram: CaptionsInstagram;
        youtube: CaptionsYouTube;
    };
    hashtags: {
        tiktok: HashtagsTikTok;
        instagram: HashtagsInstagram;
        youtube: HashtagsYouTube;
    };
    audio: Audio;
}

export interface Optimization {
    platform_specific: {
        tiktok: {
            estimated_completion_rate: number;
            remix_potential: string;
            trend_alignment: string[];
            duet_stitch_hooks: string[];
        };
        instagram: {
            estimated_save_rate: number;
            story_reshare_potential: string;
            carousel_opportunity: boolean;
            reel_play_bonus_eligible: boolean;
        };
        youtube: {
            estimated_avd_percentage: number;
            browse_feature_potential: string;
            end_screen_strategy: string;
            short_shelf_keywords: string[];
        };
    };
    improvements: {
        critical: string[];
        recommended: string[];
        experimental: string[];
    };
    metrics_targets: {
        week_1: { views: number; engagement_rate: number };
        week_2: { views: number; follower_growth: number };
        week_4: { total_reach: number; viral_coefficient: number };
    };
}

export interface Technical {
    export_settings: {
        resolution: string;
        fps: number;
        bitrate: string;
        codec: string;
        audio: string;
    };
    accessibility: {
        auto_captions: boolean;
        contrast_ratio: number;
        motion_warning: boolean;
        alt_text: string;
    };
    platform_compliance: {
        content_flags: string[];
        monetization_eligible: boolean;
        age_restriction: string;
    };
}

// The main response object from the Unified Assistant
export interface UnifiedAnalysisResponse {
    analysis?: Analysis; // Optional for topic-only input
    extracted_frames?: ExtractedFrame[]; // Optional for topic-only input
    content_package: ContentPackage;
    optimization: Optimization;
    technical: Technical;
    production_notes: string;
}