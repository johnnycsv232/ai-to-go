// FIX: The @google/genai package should be used instead of @google/ai.
import { GoogleGenAI, Type, GenerateContentResponse, Modality } from "@google/genai";
// FIX: Removed unused and undefined types GroundingResult and VideoAnalysisResult.
import type { HookScore, UnifiedAnalysisResponse } from '../types';

const API_KEY = process.env.API_KEY;

if (!API_KEY) {
  throw new Error("API_KEY environment variable is not set.");
}

const ai = new GoogleGenAI({ apiKey: API_KEY });

const handleError = (error: unknown, context: string) => {
    console.error(`Error in ${context}:`, error);
    if (error instanceof Error && error.message.includes('API key not valid')) {
       throw new Error(`Invalid API Key. Please check your environment configuration.`);
    }
    throw new Error(`Failed to fetch response from Gemini API during ${context}.`);
}

/**
 * Generates simple text content.
 */
export const generateContent = async (prompt: string, systemInstruction?: string): Promise<string> => {
  try {
    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: prompt,
      config: {
        systemInstruction: systemInstruction,
        temperature: 0.7,
        topP: 0.95,
      }
    });
    return response.text;
  } catch (error) {
    handleError(error, 'generateContent');
    return ''; // Should not be reached
  }
};

/**
 * Generates content with a specific JSON schema.
 */
export const generateJsonContent = async <T>(prompt: string, schema: any, systemInstruction?: string): Promise<T> => {
    try {
        const response = await ai.models.generateContent({
            model: "gemini-2.5-flash",
            contents: prompt,
            config: {
                systemInstruction: systemInstruction,
                responseMimeType: "application/json",
                responseSchema: schema,
            },
        });

        const jsonStr = response.text.trim();
        return JSON.parse(jsonStr) as T;

    } catch (error) {
        handleError(error, 'generateJsonContent');
        throw error;
    }
}

/**
 * Analyzes and scores a list of video hooks.
 */
export const scoreHooks = async (hooks: string[], userProfile: { niche: string, style: string }): Promise<{scores: HookScore[]}> => {
    const schema = {
        type: Type.OBJECT,
        properties: {
            scores: {
                type: Type.ARRAY,
                description: 'An array of scores, one for each hook provided.',
                items: {
                    type: Type.OBJECT,
                    properties: {
                        urgency: { type: Type.INTEGER, description: 'Score 0-100 for creating a sense of urgency.' },
                        curiosity: { type: Type.INTEGER, description: 'Score 0-100 for making the viewer curious.' },
                        emotion: { type: Type.INTEGER, description: 'Score 0-100 for emotional impact.' },
                        clarity: { type: Type.INTEGER, description: 'Score 0-100 for being clear and easy to understand.' },
                    },
                    required: ['urgency', 'curiosity', 'emotion', 'clarity']
                }
            }
        },
        required: ['scores']
    };
    
    const systemInstruction = `You are a viral marketing expert. Your job is to score video hooks based on their potential to grab attention. Be critical and accurate. The creator's niche is "${userProfile.niche}" and their style is "${userProfile.style}".`;
    const prompt = `Analyze and score the following video hooks based on the schema. The hooks are:\n\n${hooks.map((h, i) => `${i + 1}. "${h}"`).join('\n')}`;

    try {
        return await generateJsonContent<{scores: HookScore[]}>(prompt, schema, systemInstruction);
    } catch (error) {
        handleError(error, 'scoreHooks');
        throw error;
    }
};

/**
 * Generates an image from a text prompt.
 */
export const generateImage = async (prompt: string): Promise<string> => {
    try {
        const response = await ai.models.generateImages({
            model: 'imagen-4.0-generate-001',
            prompt: prompt,
            config: {
                numberOfImages: 1,
                outputMimeType: 'image/png',
            },
        });

        if (!response.generatedImages || response.generatedImages.length === 0) {
            throw new Error('No image was generated.');
        }

        const base64ImageBytes: string = response.generatedImages[0].image.imageBytes;
        return base64ImageBytes;
    } catch (error) {
        handleError(error, 'generateImage');
        return ''; // Should not be reached
    }
};

/**
 * The master function for the Unified Assistant. Handles video or topic input.
 */
export const generateUnifiedAnalysis = async (
    input: { frames: string[], topicJson?: never } | { frames?: never, topicJson: string },
    schema: any,
): Promise<UnifiedAnalysisResponse> => {
    
    // The new, highly-detailed system prompt
    const systemInstruction = `You are TrendsFeedAI Assistant (Gemini 2.5 Flash/Pro). Generate platform-optimized content packages for TikTok, Instagram Reels, and YouTube Shorts. Return ONLY valid JSON matching the schema below.

## Core Parameters
- **Brand**: TrendsFeedAI | Accent: #00E5FF | Font: Inter/Montserrat Bold
- **Video Specs**: 9:16 (1080x1920), <60s, MP4/MOV/WebM
- **Temperature**: 0.3 | Top-p: 0.8 | Response: JSON only

## Input Types
1. **Video**: Vertical video file + optional context
2. **Topic**: \`{"title": str, "category": str, "target_audience": str, "tone": str, "keywords": [str], "trend_velocity": float}\`

## Analysis Framework

### Video Scoring (0-100)
\`\`\`
hook_strength = (first_frame_impact * 0.3) + (motion_in_3s * 0.3) + (text_overlay * 0.2) + (face_presence * 0.2)
pacing_score = min(100, (cuts_per_10s * 10) + (motion_intensity * 0.5) + (audio_beat_match * 0.3))
viral_potential = (emotional_peaks * 0.4) + (shareability * 0.3) + (loop_quality * 0.3)
\`\`\`

## Platform Algorithms (2025)
**TikTok**: Completion_rate * 0.35 + Share_rate * 0.25 + Comment_rate * 0.20 + Like_rate * 0.10 + Save_rate * 0.10
**Instagram**: Save_rate * 0.30 + Share_rate * 0.25 + Watch_time * 0.25 + Comment_rate * 0.20
**YouTube**: AVD% * 0.40 + CTR * 0.30 + Engagement * 0.20 + Session_duration * 0.10

## Processing Pipeline
1. **Input Validation** → Check format, duration, aspect ratio
2. **Content Analysis** → Extract visuals, audio, text, emotions
3. **Platform Optimization** → Generate platform-specific variants
4. **Quality Assurance** → Verify compliance, accessibility, brand
5. **Output Generation** → Return complete JSON package`;
    
    try {
        let contents: any;
        const textPart = { text: '' };

        if (input.frames) {
            textPart.text = "Analyze this short-form vertical video based on the provided frames and generate a full content package according to the system prompt rules.";
            const frameParts = input.frames.map(frame => ({
                inlineData: { mimeType: 'image/jpeg', data: frame },
            }));
            contents = { parts: [textPart, ...frameParts] };
        } else {
            textPart.text = `A trending topic is provided as a JSON object. Generate a full creative content package based on this topic according to the system prompt rules.\n\nTopic JSON:\n${input.topicJson}`;
            contents = textPart.text;
        }

        const response = await ai.models.generateContent({
            model: 'gemini-2.5-flash',
            contents: contents,
            config: {
                systemInstruction: systemInstruction,
                responseMimeType: "application/json",
                responseSchema: schema,
            }
        });

        const jsonStr = response.text.trim();
        return JSON.parse(jsonStr) as UnifiedAnalysisResponse;

    } catch (error) {
        handleError(error, 'generateUnifiedAnalysis');
        throw error;
    }
};


/**
 * Edits an image using a base image and a text prompt.
 */
export const editImage = async (prompt: string, imageBase64: string, mimeType: string): Promise<string> => {
    try {
        const imagePart = {
            inlineData: {
                data: imageBase64,
                mimeType: mimeType,
            },
        };
        const textPart = { text: prompt };

        const response: GenerateContentResponse = await ai.models.generateContent({
            model: 'gemini-2.5-flash-image',
            contents: { parts: [imagePart, textPart] },
            config: {
                responseModalities: [Modality.IMAGE, Modality.TEXT],
            },
        });
        
        // Find the image part in the response
        const imageResponsePart = response.candidates?.[0]?.content?.parts?.find(part => part.inlineData);
        if (imageResponsePart?.inlineData?.data) {
            return imageResponsePart.inlineData.data;
        }

        throw new Error("AI did not return an edited image.");

    } catch (error) {
        handleError(error, 'editImage');
        return ''; // Should not be reached
    }
};