import React, { useState, useEffect } from 'react';
import { getAnalytics, clearAnalytics } from '../services/analyticsService';
import type { AnalyticsEntry } from '../types';
import ToolCard from './ToolCard';

const AnalyticsDashboard: React.FC = () => {
    const [entries, setEntries] = useState<AnalyticsEntry[]>([]);
    
    useEffect(() => {
        setEntries(getAnalytics());
    }, []);

    const handleClear = () => {
        if (window.confirm('Are you sure you want to clear all analytics history? This cannot be undone.')) {
            clearAnalytics();
            setEntries([]);
        }
    };

    const toolUsage = entries.reduce((acc, entry) => {
        acc[entry.tool] = (acc[entry.tool] || 0) + 1;
        return acc;
    }, {} as Record<AnalyticsEntry['tool'], number>);

    return (
        <ToolCard title="Analytics Dashboard" icon="📈">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {/* Usage Stats */}
                <div className="bg-gray-50 p-4 rounded-lg">
                    <h3 className="font-bold text-lg mb-2 text-gray-700">Tool Usage</h3>
                    <div className="space-y-2">
                        {/* FIX: Corrected tool names to match the AnalyticsEntry['tool'] type definition. */}
                        {(['Unified Analysis', 'Image Generation', 'Other'] as AnalyticsEntry['tool'][]).map(toolName => (
                            <div key={toolName} className="flex justify-between items-center text-sm">
                                <span className="text-gray-600">{toolName}</span>
                                <span className="font-bold bg-indigo-100 text-indigo-700 px-2 py-1 rounded-full">{toolUsage[toolName] || 0}</span>
                            </div>
                        ))}
                    </div>
                </div>

                {/* History Log */}
                <div className="bg-gray-50 p-4 rounded-lg">
                     <div className="flex justify-between items-center mb-2">
                        <h3 className="font-bold text-lg text-gray-700">Recent Activity</h3>
                        <button onClick={handleClear} className="text-xs bg-red-100 text-red-700 hover:bg-red-200 px-2 py-1 rounded-md">Clear History</button>
                    </div>
                    <div className="max-h-60 overflow-y-auto space-y-2 pr-2">
                        {entries.length > 0 ? entries.map(entry => (
                            <div key={entry.id} className="p-2 bg-white rounded-md shadow-sm text-xs">
                                <div className="flex justify-between items-center">
                                    <span className="font-semibold text-indigo-600">{entry.tool}</span>
                                    <span className="text-gray-400">{new Date(entry.timestamp).toLocaleString()}</span>
                                </div>
                                {entry.details.videoFileName && <p className="text-gray-500 truncate">File: {entry.details.videoFileName}</p>}
                                {/* FIX: Changed 'platform' to 'inputType' as 'platform' does not exist on the details object. */}
                                {entry.details.inputType && <p className="text-gray-500">Input Type: {entry.details.inputType}</p>}
                            </div>
                        )) : (
                            <p className="text-sm text-gray-500 text-center py-4">No activity yet. Use the tools to see your history here!</p>
                        )}
                    </div>
                </div>
            </div>
        </ToolCard>
    );
};

export default AnalyticsDashboard;