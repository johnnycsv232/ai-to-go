
import React, { useState, useContext } from 'react';
import ToolCard from './ToolCard';
import StatBox from './StatBox';
import { generateContent } from '../services/geminiService';
import OutputDisplay from './OutputDisplay';
import { UserProfileContext } from '../context/UserProfileContext';

interface Revenue {
  monthly: string;
  yearly: string;
}

const RevenueEstimator: React.FC = () => {
  const { userProfile } = useContext(UserProfileContext);
  const [followers, setFollowers] = useState('');
  const [avgViews, setAvgViews] = useState('');
  const [streams, setStreams] = useState({
    creatorFund: false,
    sponsorships: false,
    affiliate: false,
  });
  const [revenue, setRevenue] = useState<Revenue | null>(null);
  const [tips, setTips] = useState('');
  const [isGeneratingTips, setIsGeneratingTips] = useState(false);
  const [error, setError] = useState('');

  const handleCheckboxChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    const { id, checked } = event.target;
    setStreams(prev => ({ ...prev, [id]: checked }));
  };

  const estimateRevenue = () => {
    setTips('');
    const numFollowers = parseInt(followers) || 0;
    if (numFollowers === 0) {
      alert('Please enter follower count.');
      return;
    }
    const numAvgViews = parseInt(avgViews) || 0;
    let monthly = 0;

    if (streams.creatorFund && numFollowers >= 10000) {
      monthly += (numAvgViews * 30 * 0.0002); // Simplified RPM
    }
    if (streams.sponsorships && numFollowers >= 20000) {
      const sponsorRate = numFollowers < 50000 ? 200 : (numFollowers < 100000 ? 500 : 1000);
      monthly += sponsorRate * 2;
    }
    if (streams.affiliate && numFollowers >= 5000) {
      monthly += numFollowers * 0.01;
    }

    setRevenue({
      monthly: `$${Math.round(monthly).toLocaleString()}`,
      yearly: `$${Math.round(monthly * 12).toLocaleString()}`,
    });
  };

  const getAiTips = async () => {
    if (!revenue) return;
    setIsGeneratingTips(true);
    setError('');
    setTips('');

    const selectedStreams = Object.entries(streams).filter(([, val]) => val).map(([key]) => key).join(', ') || 'none';
    const systemInstruction = `You are an expert business coach for content creators. The user's creator profile is: Niche: "${userProfile.niche}", Target Audience: "${userProfile.audience}", Content Style: "${userProfile.style}". Use this profile to give highly relevant, specific advice.`;

    const prompt = `A content creator has ${followers} followers and gets an average of ${avgViews} views per video.
Their current revenue streams are: ${selectedStreams}.
Their estimated monthly revenue is ${revenue.monthly}.

Based on their profile, provide 3 actionable, strategic tips for this creator to increase their revenue. The tips should be relevant to their current size and monetization methods. Format as a numbered list.`;

    try {
        const result = await generateContent(prompt, systemInstruction);
        setTips(result);
    } catch (err) {
        setError('Failed to get AI growth tips.');
    } finally {
        setIsGeneratingTips(false);
    }
  }

  return (
    <ToolCard title="Revenue Estimator" icon="💰">
      <div className="form-group">
        <label htmlFor="followers" className="block text-sm font-medium text-gray-700 mb-1">Current Followers:</label>
        <input
          type="number"
          id="followers"
          value={followers}
          onChange={(e) => setFollowers(e.target.value)}
          placeholder="e.g., 25000"
          className="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-indigo-500 focus:border-indigo-500"
        />
      </div>
      <div className="form-group">
        <label htmlFor="avgViews" className="block text-sm font-medium text-gray-700 mb-1">Avg Views per Video:</label>
        <input
          type="number"
          id="avgViews"
          value={avgViews}
          onChange={(e) => setAvgViews(e.target.value)}
          placeholder="e.g., 100000"
          className="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-indigo-500 focus:border-indigo-500"
        />
      </div>
      <div className="form-group">
        <label className="block text-sm font-medium text-gray-700 mb-1">Revenue Streams:</label>
        <div className="flex flex-wrap gap-x-4 gap-y-2">
          {['creatorFund', 'sponsorships', 'affiliate'].map(id => (
            <div className="flex items-center" key={id}>
              <input
                type="checkbox"
                id={id}
                checked={streams[id as keyof typeof streams]}
                onChange={handleCheckboxChange}
                className="h-4 w-4 text-indigo-600 border-gray-300 rounded focus:ring-indigo-500"
              />
              <label htmlFor={id} className="ml-2 block text-sm text-gray-900 capitalize">{id.replace('Fund', ' Fund')}</label>
            </div>
          ))}
        </div>
      </div>
      <button
        onClick={estimateRevenue}
        className="w-full bg-gradient-to-r from-indigo-500 to-purple-600 text-white font-bold py-2 px-4 rounded-md hover:opacity-90 transition-opacity"
      >
        Estimate Revenue ✨
      </button>
      {revenue && (
        <div className="stats-grid grid grid-cols-2 gap-4 mt-4">
          <StatBox label="Monthly Estimate" value={revenue.monthly} />
          <StatBox label="Yearly Potential" value={revenue.yearly} />
        </div>
      )}
      {revenue && (
         <div className="mt-4">
            <button
                onClick={getAiTips}
                disabled={isGeneratingTips}
                className="w-full bg-gradient-to-r from-teal-500 to-cyan-600 text-white font-bold py-2 px-4 rounded-md hover:opacity-90 transition-opacity disabled:opacity-50"
            >
                {isGeneratingTips ? 'Generating...' : 'Get AI Growth Tips 💡'}
            </button>
        </div>
      )}
      {error && <p className="text-red-500 text-sm mt-2">{error}</p>}
      <OutputDisplay text={tips} isLoading={isGeneratingTips} />
    </ToolCard>
  );
};

export default RevenueEstimator;
