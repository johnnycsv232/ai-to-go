
import React from 'react';
import type { StatBoxProps } from '../types';

const StatBox: React.FC<StatBoxProps> = ({ label, value }) => {
  return (
    <div className="bg-indigo-50 p-4 rounded-lg text-center shadow-inner">
      <div className="stat-value text-2xl font-bold text-indigo-600">{value}</div>
      <div className="stat-label text-sm text-gray-600 mt-1">{label}</div>
    </div>
  );
};

export default StatBox;
