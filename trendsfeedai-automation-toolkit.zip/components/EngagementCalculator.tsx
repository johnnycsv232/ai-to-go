
import React, { useState, useContext } from 'react';
import ToolCard from './ToolCard';
import StatBox from './StatBox';
import { generateContent } from '../services/geminiService';
import OutputDisplay from './OutputDisplay';
import { UserProfileContext } from '../context/UserProfileContext';

interface Stats {
  engagementRate: string;
  viralScore: number;
  qualityScore: string;
  projectedFollowers: string;
}

const EngagementCalculator: React.FC = () => {
  const { userProfile } = useContext(UserProfileContext);
  const [views, setViews] = useState('');
  const [likes, setLikes] = useState('');
  const [comments, setComments] = useState('');
  const [shares, setShares] = useState('');
  const [stats, setStats] = useState<Stats | null>(null);
  const [analysis, setAnalysis] = useState('');
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [error, setError] = useState('');

  const calculateEngagement = () => {
    setAnalysis('');
    const numViews = parseInt(views) || 0;
    if (numViews === 0) {
      alert('Please enter total views.');
      return;
    }
    const numLikes = parseInt(likes) || 0;
    const numComments = parseInt(comments) || 0;
    const numShares = parseInt(shares) || 0;

    const totalEngagement = numLikes + numComments + numShares;
    const rate = ((totalEngagement / numViews) * 100).toFixed(2);
    const vScore = Math.min(100, Math.round((numShares / numViews * 100) * 1000));
    
    let quality = 'Poor';
    const numericRate = parseFloat(rate);
    if (numericRate > 8) quality = 'Excellent';
    else if (numericRate > 5) quality = 'Great';
    else if (numericRate > 3) quality = 'Good';
    else if (numericRate > 1) quality = 'Average';

    const followerRate = numViews > 100000 ? 0.02 : 0.01;
    const projFollowers = Math.round(numViews * followerRate);

    setStats({
      engagementRate: `${rate}%`,
      viralScore: vScore,
      qualityScore: quality,
      projectedFollowers: projFollowers.toLocaleString(),
    });
  };

  const getAiAnalysis = async () => {
    if (!stats) return;
    setIsAnalyzing(true);
    setError('');
    setAnalysis('');

    const systemInstruction = `You are an expert social media analyst. The user's creator profile is: Niche: "${userProfile.niche}", Target Audience: "${userProfile.audience}", Content Style: "${userProfile.style}". Use this profile to provide highly relevant, specific feedback.`;

    const prompt = `A social media video received the following stats:
- Views: ${views}
- Likes: ${likes}
- Comments: ${comments}
- Shares: ${shares}
- Engagement Rate: ${stats.engagementRate}

Based on these metrics and the user's creator profile, provide a brief analysis of the video's performance and give 3 actionable, concise tips to improve engagement on the next video. Format the tips as a numbered list.`;

    try {
        const result = await generateContent(prompt, systemInstruction);
        setAnalysis(result);
    } catch (err) {
        setError('Failed to get AI analysis.');
    } finally {
        setIsAnalyzing(false);
    }
  };

  return (
    <ToolCard title="Engagement Calculator" icon="📊">
      {['Total Views', 'Likes', 'Comments', 'Shares'].map((label) => {
        const id = `total${label.split(' ')[1] || 'Views'}`;
        const value = {views, likes, comments, shares}[id.replace('total','').toLowerCase() as 'views'|'likes'|'comments'|'shares'];
        const setter = {setViews, setLikes, setComments, setShares}[`set${id.replace('total','')}` as 'setViews'|'setLikes'|'setComments'|'setShares'];
        return (
            <div className="form-group" key={id}>
                <label htmlFor={id} className="block text-sm font-medium text-gray-700 mb-1">{label}:</label>
                <input
                    type="number"
                    id={id}
                    value={value}
                    onChange={(e) => setter(e.target.value)}
                    placeholder={`e.g., ${id === 'totalViews' ? '50000' : id === 'totalLikes' ? '5000' : id === 'totalComments' ? '250' : '100'}`}
                    className="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-indigo-500 focus:border-indigo-500"
                />
            </div>
        )
      })}
      <button
        onClick={calculateEngagement}
        className="w-full bg-gradient-to-r from-indigo-500 to-purple-600 text-white font-bold py-2 px-4 rounded-md hover:opacity-90 transition-opacity"
      >
        Calculate Metrics ✨
      </button>
      {stats && (
        <div className="stats-grid grid grid-cols-2 gap-4 mt-4">
          <StatBox label="Engagement Rate" value={stats.engagementRate} />
          <StatBox label="Viral Score" value={stats.viralScore} />
          <StatBox label="Content Quality" value={stats.qualityScore} />
          <StatBox label="Est. New Followers" value={stats.projectedFollowers} />
        </div>
      )}
      {stats && (
        <div className="mt-4">
            <button
                onClick={getAiAnalysis}
                disabled={isAnalyzing}
                className="w-full bg-gradient-to-r from-teal-500 to-cyan-600 text-white font-bold py-2 px-4 rounded-md hover:opacity-90 transition-opacity disabled:opacity-50"
            >
                {isAnalyzing ? 'Analyzing...' : 'Get AI Analysis 🧠'}
            </button>
        </div>
      )}
      {error && <p className="text-red-500 text-sm mt-2">{error}</p>}
      <OutputDisplay text={analysis} isLoading={isAnalyzing} />
    </ToolCard>
  );
};

export default EngagementCalculator;
