
import React, { useState } from 'react';
import ToolCard from './ToolCard';
import { generateImage } from '../services/geminiService';

const ImageGenerator: React.FC = () => {
  const [prompt, setPrompt] = useState('');
  const [imageBase64, setImageBase64] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState('');

  const handleGenerate = async () => {
    if (!prompt) {
      setError('Please enter an image prompt.');
      return;
    }
    setError('');
    setIsLoading(true);
    setImageBase64('');

    try {
      const generatedImage = await generateImage(prompt);
      setImageBase64(generatedImage);
    } catch (err) {
      setError('Failed to generate image. Please try again.');
      console.error(err);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <ToolCard title="AI Image Generator" icon="🎨">
      <div className="form-group">
        <label htmlFor="imagePrompt" className="block text-sm font-medium text-gray-700 mb-1">Image Prompt:</label>
        <textarea
          id="imagePrompt"
          value={prompt}
          onChange={(e) => setPrompt(e.target.value)}
          placeholder="e.g., A robot holding a red skateboard."
          className="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 min-h-[60px]"
          rows={3}
        />
      </div>
      <button
        onClick={handleGenerate}
        disabled={isLoading}
        className="w-full bg-gradient-to-r from-indigo-500 to-purple-600 text-white font-bold py-2 px-4 rounded-md hover:opacity-90 transition-opacity disabled:opacity-50 disabled:cursor-not-allowed"
      >
        {isLoading ? 'Generating...' : 'Generate Image 🚀'}
      </button>
      {error && <p className="text-red-500 text-sm mt-2">{error}</p>}
      
      <div className="output mt-4">
        {isLoading && (
            <div className="flex items-center justify-center text-gray-600 p-4 bg-gray-100 rounded-lg">
                <svg className="animate-spin -ml-1 mr-3 h-5 w-5 text-indigo-500" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                    <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                    <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                </svg>
                Generating image... this can take a moment.
            </div>
        )}
        {imageBase64 && !isLoading && (
            <div className="p-4 bg-gray-100 rounded-lg border-l-4 border-indigo-500 space-y-3">
                <img 
                    src={`data:image/png;base64,${imageBase64}`}
                    alt="AI generated image"
                    className="rounded-lg w-full h-auto"
                />
                <a
                  href={`data:image/png;base64,${imageBase64}`}
                  download={`trendsfeedai-${prompt.slice(0, 20).replace(/\s/g, '_')}.png`}
                  className="block w-full text-center mt-4 bg-green-500 text-white font-bold py-2 px-4 rounded-md hover:bg-green-600 transition-colors text-sm"
                >
                  Download Image 🖼️
                </a>
            </div>
        )}
      </div>
    </ToolCard>
  );
};

export default ImageGenerator;
