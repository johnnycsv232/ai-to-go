
import React from 'react';
import type { ToolCardProps } from '../types';

const ToolCard: React.FC<ToolCardProps> = ({ title, icon, children }) => {
  return (
    <div className="bg-white/95 backdrop-blur-sm rounded-2xl p-6 shadow-xl hover:shadow-2xl transition-shadow duration-300 transform hover:-translate-y-1">
      <div className="flex items-center mb-4 pb-4 border-b-2 border-indigo-200">
        <div className="text-3xl mr-4">{icon}</div>
        <h2 className="text-xl font-bold text-gray-800">{title}</h2>
      </div>
      <div className="space-y-4">
        {children}
      </div>
    </div>
  );
};

export default ToolCard;
