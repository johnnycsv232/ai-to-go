import React, { useState, useCallback, useContext, FC } from 'react';
import { useDropzone } from 'react-dropzone';
import { Type } from "@google/genai";
import ToolCard from './ToolCard';
import StatBox from './StatBox';
import { UserProfileContext } from '../context/UserProfileContext';
import { generateUnifiedAnalysis } from '../services/geminiService';
import { trackEvent } from '../services/analyticsService';
import type { UnifiedAnalysisResponse, VideoFrame, ExtractedFrame } from '../types';

// The strict JSON schema provided by the user (v2.0)
const unifiedAnalysisSchema = {
    type: Type.OBJECT,
    properties: {
        analysis: {
            type: Type.OBJECT,
            description: "Omit if no video is provided.",
            properties: {
                hook_strength: { type: Type.NUMBER },
                pacing_score: { type: Type.NUMBER },
                viral_potential: { type: Type.NUMBER },
                emotional_peaks: { type: Type.ARRAY, items: { type: Type.OBJECT, properties: { timestamp: { type: Type.NUMBER }, emotion: { type: Type.STRING }, intensity: { type: Type.NUMBER } } } },
                retention_curve: { type: Type.ARRAY, items: { type: Type.NUMBER } },
                accessibility_score: { type: Type.NUMBER }
            }
        },
        extracted_frames: {
            type: Type.ARRAY,
            description: "Omit if no video is provided.",
            items: {
                type: Type.OBJECT,
                properties: {
                    timestamp: { type: Type.NUMBER },
                    purpose: { type: Type.STRING },
                    visual_elements: { type: Type.ARRAY, items: { type: Type.STRING } },
                    emotion_detected: { type: Type.STRING },
                    text_readability: { type: Type.NUMBER }
                }
            }
        },
        content_package: {
            type: Type.OBJECT,
            properties: {
                thumbnail: {
                    type: Type.OBJECT,
                    properties: {
                        primary_text: { type: Type.STRING },
                        secondary_text: { type: Type.STRING },
                        visual_style: { type: Type.STRING },
                        color_scheme: { type: Type.OBJECT, properties: { primary: { type: Type.STRING }, secondary: { type: Type.STRING }, accent: { type: Type.STRING } } },
                        element_layout: { type: Type.ARRAY, items: { type: Type.OBJECT, properties: { type: { type: Type.STRING }, position: { type: Type.STRING }, size: { type: Type.STRING } } } },
                        a_b_variant: { type: Type.STRING }
                    }
                },
                captions: {
                    type: Type.OBJECT,
                    properties: {
                        tiktok: { type: Type.OBJECT, properties: { primary: { type: Type.STRING }, hook_variant_a: { type: Type.STRING }, hook_variant_b: { type: Type.STRING }, engagement_triggers: { type: Type.ARRAY, items: { type: Type.STRING } } } },
                        instagram: { type: Type.OBJECT, properties: { primary: { type: Type.STRING }, first_line: { type: Type.STRING }, cta_options: { type: Type.ARRAY, items: { type: Type.STRING } }, save_triggers: { type: Type.ARRAY, items: { type: Type.STRING } } } },
                        youtube: { type: Type.OBJECT, properties: { title: { type: Type.STRING }, description_snippet: { type: Type.STRING }, chapters: { type: Type.ARRAY, items: { type: Type.OBJECT, properties: { time: { type: Type.STRING }, title: { type: Type.STRING } } } }, seo_keywords: { type: Type.ARRAY, items: { type: Type.STRING } } } }
                    }
                },
                hashtags: {
                    type: Type.OBJECT,
                    properties: {
                        tiktok: { type: Type.OBJECT, properties: { primary: { type: Type.ARRAY, items: { type: Type.STRING } }, experimental: { type: Type.ARRAY, items: { type: Type.STRING } }, branded: { type: Type.ARRAY, items: { type: Type.STRING } } } },
                        instagram: { type: Type.OBJECT, properties: { visible: { type: Type.ARRAY, items: { type: Type.STRING } }, hidden: { type: Type.ARRAY, items: { type: Type.STRING } }, location_tags: { type: Type.ARRAY, items: { type: Type.STRING } } } },
                        youtube: { type: Type.OBJECT, properties: { tags: { type: Type.ARRAY, items: { type: Type.STRING } }, category: { type: Type.STRING } } }
                    }
                },
                audio: {
                    type: Type.OBJECT,
                    properties: {
                        voiceover_script: { type: Type.STRING },
                        duration: { type: Type.NUMBER },
                        tts_config: { type: Type.OBJECT, properties: { platform_variants: { type: Type.OBJECT, properties: { tiktok: { type: Type.OBJECT, properties: { voice_id: { type: Type.STRING }, params: { type: Type.OBJECT, properties: {} } } }, instagram: { type: Type.OBJECT, properties: { voice_id: { type: Type.STRING }, params: { type: Type.OBJECT, properties: {} } } }, youtube: { type: Type.OBJECT, properties: { voice_id: { type: Type.STRING }, params: { type: Type.OBJECT, properties: {} } } } } } } },
                        music_recommendation: { type: Type.OBJECT, properties: { genre: { type: Type.STRING }, bpm: { type: Type.INTEGER }, energy_level: { type: Type.STRING }, trending_audio_id: { type: Type.STRING } } },
                        sound_effects: { type: Type.ARRAY, items: { type: Type.OBJECT, properties: { type: { type: Type.STRING }, timestamp: { type: Type.NUMBER } } } }
                    }
                }
            }
        },
        optimization: {
            type: Type.OBJECT,
            properties: {
                platform_specific: {
                    type: Type.OBJECT,
                    properties: {
                        tiktok: { type: Type.OBJECT, properties: { estimated_completion_rate: { type: Type.NUMBER }, remix_potential: { type: Type.STRING }, trend_alignment: { type: Type.ARRAY, items: { type: Type.STRING } }, duet_stitch_hooks: { type: Type.ARRAY, items: { type: Type.STRING } } } },
                        instagram: { type: Type.OBJECT, properties: { estimated_save_rate: { type: Type.NUMBER }, story_reshare_potential: { type: Type.STRING }, carousel_opportunity: { type: Type.BOOLEAN }, reel_play_bonus_eligible: { type: Type.BOOLEAN } } },
                        youtube: { type: Type.OBJECT, properties: { estimated_avd_percentage: { type: Type.NUMBER }, browse_feature_potential: { type: Type.STRING }, end_screen_strategy: { type: Type.STRING }, short_shelf_keywords: { type: Type.ARRAY, items: { type: Type.STRING } } } }
                    }
                },
                improvements: { type: Type.OBJECT, properties: { critical: { type: Type.ARRAY, items: { type: Type.STRING } }, recommended: { type: Type.ARRAY, items: { type: Type.STRING } }, experimental: { type: Type.ARRAY, items: { type: Type.STRING } } } },
                metrics_targets: { type: Type.OBJECT, properties: { week_1: { type: Type.OBJECT, properties: { views: { type: Type.INTEGER }, engagement_rate: { type: Type.NUMBER } } }, week_2: { type: Type.OBJECT, properties: { views: { type: Type.INTEGER }, follower_growth: { type: Type.NUMBER } } }, week_4: { type: Type.OBJECT, properties: { total_reach: { type: Type.INTEGER }, viral_coefficient: { type: Type.NUMBER } } } } }
            }
        },
        technical: {
            type: Type.OBJECT,
            properties: {
                export_settings: { type: Type.OBJECT, properties: { resolution: { type: Type.STRING }, fps: { type: Type.INTEGER }, bitrate: { type: Type.STRING }, codec: { type: Type.STRING }, audio: { type: Type.STRING } } },
                accessibility: { type: Type.OBJECT, properties: { auto_captions: { type: Type.BOOLEAN }, contrast_ratio: { type: Type.NUMBER }, motion_warning: { type: Type.BOOLEAN }, alt_text: { type: Type.STRING } } },
                platform_compliance: { type: Type.OBJECT, properties: { content_flags: { type: Type.ARRAY, items: { type: Type.STRING } }, monetization_eligible: { type: Type.BOOLEAN }, age_restriction: { type: Type.STRING } } }
            }
        },
        production_notes: { type: Type.STRING }
    },
    required: ["content_package", "optimization", "technical", "production_notes"]
};

const FRAME_COUNT = 16;

const extractFramesFromVideo = (videoFile: File): Promise<VideoFrame[]> => {
    return new Promise((resolve, reject) => {
        const video = document.createElement('video');
        const canvas = document.createElement('canvas');
        const ctx = canvas.getContext('2d');
        const frames: VideoFrame[] = [];
        
        video.preload = 'metadata';
        video.src = URL.createObjectURL(videoFile);
        video.muted = true;

        video.onloadedmetadata = () => {
            canvas.width = video.videoWidth;
            canvas.height = video.videoHeight;
            const duration = video.duration;
            if (duration > 65) { // Add buffer
                 reject(new Error("Video is longer than 60 seconds."));
                 return;
            }
            const interval = duration / FRAME_COUNT;
            let currentTime = 0;
            let framesExtracted = 0;

            const extractFrame = () => {
                if (framesExtracted >= FRAME_COUNT) {
                    URL.revokeObjectURL(video.src);
                    resolve(frames);
                    return;
                }
                video.currentTime = currentTime;
            };

            video.onseeked = () => {
                if (ctx) {
                    ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
                    const base64 = canvas.toDataURL('image/jpeg', 0.8).split(',')[1];
                    frames.push({ data: base64, timestamp: video.currentTime });
                    framesExtracted++;
                    currentTime += interval;
                    if (currentTime > duration) currentTime = duration;
                    // Use setTimeout to allow the event loop to breathe and prevent freezing on heavy videos.
                    setTimeout(extractFrame, 0);
                }
            };
            extractFrame();
        };
        video.onerror = (e) => {
            console.error("Video error:", e);
            reject(new Error("Failed to load or process the video file. It may be corrupt."));
        };
    });
};

const AccordionItem: FC<{ title: string; children: React.ReactNode; icon: string }> = ({ title, children, icon }) => {
    const [isOpen, setIsOpen] = useState(true);
    return (
        <div className="bg-gray-800/50 rounded-lg">
            <button onClick={() => setIsOpen(!isOpen)} className="w-full flex justify-between items-center p-4 font-bold text-lg text-[#00E5FF]">
                <span>{icon} {title}</span>
                <span className={`transform transition-transform ${isOpen ? 'rotate-180' : ''}`}>▼</span>
            </button>
            {isOpen && <div className="p-4 border-t border-gray-700">{children}</div>}
        </div>
    );
};

const UnifiedAssistant: React.FC = () => {
    const [mode, setMode] = useState<'video' | 'topic'>('video');
    const [videoFile, setVideoFile] = useState<File | null>(null);
    const [topicJson, setTopicJson] = useState(JSON.stringify({
        "title": "The Future of Brain-Computer Interfaces",
        "category": "Technology",
        "target_audience": "Tech enthusiasts, neuroscientists, futurists",
        "tone": "Awe-inspiring and slightly cautious",
        "keywords": ["BCI", "Neuralink", "neuroscience", "future tech"],
        "trend_velocity": 0.85
    }, null, 2));
    const [status, setStatus] = useState<'idle' | 'processing' | 'analyzing' | 'success' | 'error'>('idle');
    const [error, setError] = useState<string | null>(null);
    const [result, setResult] = useState<UnifiedAnalysisResponse | null>(null);
    const [frames, setFrames] = useState<VideoFrame[]>([]);
    const [showRawJson, setShowRawJson] = useState(false);

    const onDrop = useCallback((acceptedFiles: File[]) => {
        if (acceptedFiles.length > 0) {
            setVideoFile(acceptedFiles[0]);
            setResult(null);
            setStatus('idle');
        }
    }, []);

    const { getRootProps, getInputProps, isDragActive } = useDropzone({
        onDrop,
        accept: { 'video/mp4': ['.mp4'], 'video/quicktime': ['.mov'] },
        maxFiles: 1,
    });
    
    const resetState = () => {
        setError(null);
        setResult(null);
        setStatus('idle');
        setFrames([]);
    };

    const handleAnalyze = async () => {
        resetState();
        setStatus('processing');
        try {
            let analysisResult: UnifiedAnalysisResponse;
            if (mode === 'video' && videoFile) {
                const extractedFrames = await extractFramesFromVideo(videoFile);
                setFrames(extractedFrames);
                setStatus('analyzing');
                analysisResult = await generateUnifiedAnalysis(
                    { frames: extractedFrames.map(f => f.data) },
                    unifiedAnalysisSchema,
                );
                trackEvent('Unified Analysis', { inputType: 'Video', videoFileName: videoFile.name });
            } else {
                 setStatus('analyzing');
                 analysisResult = await generateUnifiedAnalysis(
                    { topicJson },
                    unifiedAnalysisSchema,
                );
                trackEvent('Unified Analysis', { inputType: 'Topic' });
            }
            setResult(analysisResult);
            setStatus('success');
        } catch (err) {
            const errorMessage = err instanceof Error ? err.message : 'An unknown error occurred.';
            setError(errorMessage);
            setStatus('error');
        }
    };
    
    const findFrameData = (timestamp: number): string | undefined => {
        if (frames.length === 0) return undefined;
        const closestFrame = frames.reduce((prev, curr) => 
            Math.abs(curr.timestamp - timestamp) < Math.abs(prev.timestamp - timestamp) ? curr : prev
        );
        return closestFrame.data;
    }

    const renderStatusMessage = () => {
         switch (status) {
            case 'processing': return "⚙️ Extracting frames...";
            case 'analyzing': return "🧠 AI is analyzing... this can take a moment.";
            case 'success': return "✅ Analysis Complete!";
            case 'error': return `❌ Error: ${error}`;
            default: return null;
        }
    }

    return (
        <ToolCard title="Unified Content Assistant" icon="✨">
            <div className="flex border-b border-gray-700">
                <button onClick={() => setMode('video')} className={`px-4 py-2 text-sm font-bold transition-colors ${mode === 'video' ? 'border-b-2 border-[#00E5FF] text-white' : 'text-gray-400 hover:text-white'}`}>Analyze Video 🎥</button>
                <button onClick={() => setMode('topic')} className={`px-4 py-2 text-sm font-bold transition-colors ${mode === 'topic' ? 'border-b-2 border-[#00E5FF] text-white' : 'text-gray-400 hover:text-white'}`}>Analyze Topic 📈</button>
            </div>

            <div className="p-4 bg-gray-800/50 rounded-b-lg">
                {mode === 'video' ? (
                     !videoFile ? (
                        <div {...getRootProps()} className={`p-10 border-4 border-dashed rounded-xl text-center cursor-pointer transition-colors ${isDragActive ? 'border-[#00E5FF] bg-gray-700' : 'border-gray-600 hover:border-[#00E5FF]/50'}`}>
                            <input {...getInputProps()} />
                            <p className="text-gray-300">{isDragActive ? 'Drop the video here!' : 'Drag & drop a video file here, or click to select'}</p>
                            <p className="text-sm text-gray-500 mt-2">MP4 or MOV (&lt;60s)</p>
                        </div>
                    ) : (
                        <div className="text-center">
                            <p className="font-medium text-gray-300">File: <span className="font-bold text-[#00E5FF]">{videoFile.name}</span></p>
                            <button onClick={() => setVideoFile(null)} className="text-xs text-gray-400 hover:text-white underline mt-1">Change Video</button>
                        </div>
                    )
                ) : (
                    <div>
                        <label htmlFor="topicJson" className="block text-sm font-medium text-gray-300 mb-1">Trending Topic (JSON format):</label>
                        <textarea id="topicJson" value={topicJson} onChange={e => setTopicJson(e.target.value)} rows={8} className="w-full bg-gray-900 text-gray-200 p-2 rounded-md border border-gray-600 focus:ring-1 focus:ring-[#00E5FF] focus:border-[#00E5FF] font-mono text-sm"></textarea>
                    </div>
                )}

                <button
                    onClick={handleAnalyze}
                    disabled={status === 'processing' || status === 'analyzing' || (mode === 'video' && !videoFile)}
                    className="w-full mt-4 bg-gradient-to-r from-[#00E5FF] to-blue-500 text-black font-bold py-3 px-4 rounded-md hover:opacity-90 transition-opacity disabled:opacity-50 disabled:cursor-not-allowed"
                >
                    {status === 'analyzing' || status === 'processing' ? 'Analyzing...' : 'Generate Content Package 🚀'}
                </button>
            </div>
            
            {renderStatusMessage() && <div className="mt-4 p-3 bg-gray-800 rounded-lg text-center font-semibold">{renderStatusMessage()}</div>}

            {status === 'success' && result && (
                <div className="mt-6 space-y-4">
                    {/* Analysis Section */}
                    {result.analysis && (
                        <AccordionItem title="Analysis Scores" icon="📊">
                             <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4">
                                <StatBox label="Hook" value={`${result.analysis.hook_strength.toFixed(0)}/100`} />
                                <StatBox label="Pacing" value={`${result.analysis.pacing_score.toFixed(0)}/100`} />
                                <StatBox label="Viral Potential" value={`${result.analysis.viral_potential.toFixed(0)}/100`} />
                                <StatBox label="Accessibility" value={`${result.analysis.accessibility_score.toFixed(0)}/100`} />
                            </div>
                        </AccordionItem>
                    )}

                    {/* Content Package Section */}
                    <AccordionItem title="Content Package" icon="📦">
                        <div className="space-y-4">
                            {/* Captions & Hashtags */}
                            <div className="p-4 bg-black/20 rounded-lg">
                                <h3 className="font-bold text-lg text-[#00E5FF] mb-3">Captions & Hashtags</h3>
                                <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-sm">
                                    {([ 'tiktok', 'instagram', 'youtube' ] as const).map(p => {
                                        // FIX: Accessing properties on union types requires type narrowing.
                                        // This logic correctly selects the caption and hashtags for each platform and fixes a runtime bug for Instagram hashtags.
                                        const captionText = p === 'youtube' 
                                            ? result.content_package.captions.youtube.title 
                                            : result.content_package.captions[p].primary;
                                
                                        const hashtags = 
                                            p === 'tiktok' ? result.content_package.hashtags.tiktok.primary :
                                            p === 'instagram' ? result.content_package.hashtags.instagram.visible :
                                            result.content_package.hashtags.youtube.tags;
                                
                                        return (
                                            <div key={p}>
                                                <h4 className="font-bold capitalize text-white mb-2">{p}</h4>
                                                <p className="text-gray-300 whitespace-pre-wrap">{captionText}</p>
                                                <p className="text-xs text-cyan-300 mt-2 break-words">{hashtags.join(' ')}</p>
                                            </div>
                                        );
                                    })}
                                </div>
                            </div>
                             {/* Thumbnail & Audio */}
                             <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
                                <div className="p-4 bg-black/20 rounded-lg">
                                    <h3 className="font-bold text-lg text-[#00E5FF] mb-2">Thumbnail</h3>
                                    <p><span className="font-bold">Text:</span> "{result.content_package.thumbnail.primary_text}"</p>
                                    <p><span className="font-bold">Style:</span> {result.content_package.thumbnail.visual_style}</p>
                                </div>
                                 <div className="p-4 bg-black/20 rounded-lg">
                                    <h3 className="font-bold text-lg text-[#00E5FF] mb-2">Audio</h3>
                                     <p className="font-bold">VO Script:</p>
                                    <p className="text-sm text-gray-300 mt-1 whitespace-pre-wrap max-h-24 overflow-y-auto">{result.content_package.audio.voiceover_script}</p>
                                </div>
                             </div>
                        </div>
                    </AccordionItem>
                    
                    {/* Optimization Section */}
                    <AccordionItem title="Optimization Strategy" icon="📈">
                         <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                            <div>
                                <h4 className="font-bold text-white mb-2">Improvement Tips</h4>
                                <div className="text-sm space-y-3">
                                    <div>
                                        <h5 className="font-semibold text-red-400">Critical</h5>
                                        <ul className="list-disc list-inside text-gray-300">{result.optimization.improvements.critical.map((tip, i) => <li key={i}>{tip}</li>)}</ul>
                                    </div>
                                    <div>
                                        <h5 className="font-semibold text-yellow-400">Recommended</h5>
                                        <ul className="list-disc list-inside text-gray-300">{result.optimization.improvements.recommended.map((tip, i) => <li key={i}>{tip}</li>)}</ul>
                                    </div>
                                    <div>
                                        <h5 className="font-semibold text-green-400">Experimental</h5>
                                        <ul className="list-disc list-inside text-gray-300">{result.optimization.improvements.experimental.map((tip, i) => <li key={i}>{tip}</li>)}</ul>
                                    </div>
                                </div>
                            </div>
                            <div>
                               <h4 className="font-bold text-white mb-2">Metric Targets</h4>
                               <div className="space-y-2 text-sm">
                                   <p><strong>Week 1:</strong> {result.optimization.metrics_targets.week_1.views.toLocaleString()} views @ {result.optimization.metrics_targets.week_1.engagement_rate}% engagement</p>
                                   <p><strong>Week 2:</strong> {result.optimization.metrics_targets.week_2.views.toLocaleString()} views, {result.optimization.metrics_targets.week_2.follower_growth.toLocaleString()} new followers</p>
                                   <p><strong>Week 4:</strong> {result.optimization.metrics_targets.week_4.total_reach.toLocaleString()} total reach, {result.optimization.metrics_targets.week_4.viral_coefficient} viral coefficient</p>
                               </div>
                            </div>
                        </div>
                    </AccordionItem>

                     {/* Extracted Frames */}
                    {result.extracted_frames && result.extracted_frames.length > 0 && frames.length > 0 && (
                       <AccordionItem title="Extracted Frames" icon="🖼️">
                            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                                {result.extracted_frames.map(frame => {
                                    const frameData = findFrameData(frame.timestamp);
                                    return frameData ? (
                                        <div key={frame.timestamp}>
                                            <img src={`data:image/jpeg;base64,${frameData}`} alt={`Frame at ${frame.timestamp}s`} className="rounded-md w-full aspect-[9/16] object-cover" />
                                            <p className="text-xs text-gray-300 mt-1"><span className="font-bold">{frame.timestamp.toFixed(1)}s:</span> {frame.purpose}</p>
                                        </div>
                                    ) : null
                                })}
                            </div>
                        </AccordionItem>
                    )}
                    
                    {/* Technical & Production */}
                    <AccordionItem title="Technical Details" icon="🔧">
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 text-sm">
                            <div>
                                <h4 className="font-bold text-white mb-2">Export Settings</h4>
                                <p><strong>Resolution:</strong> {result.technical.export_settings.resolution}</p>
                                <p><strong>Codec:</strong> {result.technical.export_settings.codec} @ {result.technical.export_settings.bitrate}</p>
                            </div>
                             <div>
                                <h4 className="font-bold text-white mb-2">Production Notes</h4>
                                <p className="text-gray-300">{result.production_notes}</p>
                            </div>
                        </div>
                    </AccordionItem>

                    {/* Raw JSON Toggle */}
                    <div className="text-center pt-4">
                        <button onClick={() => setShowRawJson(!showRawJson)} className="text-sm text-cyan-400 hover:underline">
                            {showRawJson ? 'Hide Raw JSON' : 'View Raw JSON'}
                        </button>
                    </div>

                    {showRawJson && (
                        <pre className="bg-black/50 p-4 rounded-md text-xs text-gray-300 max-h-96 overflow-auto">
                            {JSON.stringify(result, null, 2)}
                        </pre>
                    )}
                </div>
            )}
        </ToolCard>
    );
};

export default UnifiedAssistant;
