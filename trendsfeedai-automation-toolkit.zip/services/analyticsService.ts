import type { AnalyticsEntry } from '../types';

const ANALYTICS_KEY = 'trendsFeedAiAnalytics';
const MAX_ENTRIES = 50; // Limit the number of entries to prevent localStorage from getting too large

export const trackEvent = (
  tool: AnalyticsEntry['tool'],
  details: AnalyticsEntry['details'] = {}
): void => {
  try {
    const newEntry: AnalyticsEntry = {
      id: crypto.randomUUID(),
      timestamp: Date.now(),
      tool,
      details,
    };

    const existingEntries = getAnalytics();
    const updatedEntries = [newEntry, ...existingEntries].slice(0, MAX_ENTRIES);
    
    localStorage.setItem(ANALYTICS_KEY, JSON.stringify(updatedEntries));
  } catch (error) {
    console.error('Failed to track analytics event:', error);
  }
};

export const getAnalytics = (): AnalyticsEntry[] => {
  try {
    const storedData = localStorage.getItem(ANALYTICS_KEY);
    return storedData ? JSON.parse(storedData) : [];
  } catch (error) {
    console.error('Failed to retrieve analytics data:', error);
    return [];
  }
};

export const clearAnalytics = (): void => {
  try {
    localStorage.removeItem(ANALYTICS_KEY);
  } catch (error) {
    console.error('Failed to clear analytics data:', error);
  }
};